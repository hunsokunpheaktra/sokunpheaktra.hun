var helperDialog = helperDialog || (function ($) {
	'use strict';

	// Creating modal dialog's DOM
	var $dialog = $(
		'<div class="popupHeaderInfo">' +
		'<div class="arrow-image"></div>' +
		'<label>This is Helper Text</label>' +
		'</div>');
		
	$('body').prepend($dialog);
	
	function getScreenCordinates(obj) {
		var p = {};
		p.x = obj.offsetLeft;
		p.y = obj.offsetTop;
		while (obj.offsetParent) {
			p.x = p.x + obj.offsetParent.offsetLeft;
			p.y = p.y + obj.offsetParent.offsetTop;
			if (obj == document.getElementsByTagName("body")[0]) {
				break;
			}else {
				obj = obj.offsetParent;
			}
		}
		return p;
	}
	
	return {
		show: function (activeEle, message) {
			// Assigning defaults
			var pos = getScreenCordinates(activeEle);
			pos.x -= 20;
			pos.y += 35;
			
			var posX = pos.x + $dialog.width();
			if(posX > $(window).width()){
				var distance = posX - $(window).width() + 5;
				pos.x -= distance;
				$dialog.find('.arrow-image').css("margin-left", distance+15+"px"); 
			}else{
				$dialog.find('.arrow-image').css("margin-left","15px");
			}
			
			$dialog.css({"margin-left":pos.x+"px","margin-top":pos.y+"px"});
			$dialog.find('label').text(message);
			// Opening dialog
			$dialog.show();
		},
		/**
		 * Closes dialog
		 */
		hide: function () {
			$dialog.hide();
		}
	};

})(jQuery);
